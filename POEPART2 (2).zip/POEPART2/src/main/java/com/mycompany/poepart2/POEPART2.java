/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poepart2;

/**
 *
 * @author tokol
 */
import javax.swing.JOptionPane;

public class POEPART2 {

    public static void main(String[] args) {
        boolean continueProgram = true;

        while (continueProgram) {
            int choice = JOptionPane.showOptionDialog(null, "Welcome to EasyKanban! Please select an option", "Add tasks", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Add Task", "Show Report", "Quit"}, "Add Task");

            switch (choice) {
                case 0:
                    int numTasks = getNumberOfTasks();
                    for (int i = 1; i <= numTasks; i++) {
                        String taskName = JOptionPane.showInputDialog(null, "Enter task name: ");
                        int taskNumber = generateTaskNumber();
                        String taskDescription = JOptionPane.showInputDialog(null, "Enter task description: ");
                        String taskDeveloperDetails = JOptionPane.showInputDialog(null, "Enter developer details: ");
                        int taskId = generateTaskId(taskName, taskDeveloperDetails);
                        int taskDuration = generateTaskDuration();
                        int taskStatus = getTaskStatus();
                        displayTaskInformation(i, taskName, taskDescription, taskDeveloperDetails, taskId, taskDuration, taskStatus);
                    }
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Coming soon...");
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "YOU ARE CHOOSING TO QUIT THE PROGRAM, GOODBYE!(._.)!");
                    continueProgram = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                    break;
            }
        }

        JOptionPane.showMessageDialog(null, "Thank you for using EasyKanban!");
    }

    private static int getNumberOfTasks() {
        return Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks you wish to add: "));
    }

    private static int generateTaskNumber() {
        return (int) (System.currentTimeMillis() % 100000);
    }

    private static int generateTaskId(String taskName, String taskDeveloperDetails) {
        String taskId = taskName.substring(0, 2).toUpperCase() + System.currentTimeMillis() % 100000 + ";" +
                taskDeveloperDetails.substring(Math.max(0, taskDeveloperDetails.length() - 3)).toUpperCase();
        return taskId.hashCode();
    }

    private static int generateTaskDuration() {
        return (int) (Math.random() * 10000);
    }

    private static int getTaskStatus() {
        String[] options = {"To Do", "Done", "Doing"};
        int choice = JOptionPane.showOptionDialog(null, "Select task status:", null, JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        return choice + 1;
    }

    private static void displayTaskInformation(int taskNumber, String taskName, String taskDescription, String taskDeveloperDetails, int taskId, int taskDuration, int taskStatus) {
        JOptionPane.showMessageDialog(null, "Task " + taskNumber + "\nName: " + taskName + "\nDescription: " + taskDescription +
                "\nDeveloper: " + taskDeveloperDetails + "\nTask ID: " + taskId +
                "\nDuration: " + taskDuration + " minutes\nStatus: " + getTaskStatusString(taskStatus));
    }

    private static String getTaskStatusString(int status) {
        switch (status) {
            case 1:
                return "To Do";
            case 2:
                return "Done";
            case 3:
                return "Doing";
            default:
                return "Unknown";
        }
    }
}